import os, time, socket

def handler(event, context):
    my_ip       = socket.gethostbyname(socket.gethostname())
    subnet_id   = os.environ.get("SUBNET_ID", "unknown")
    subnet_name = os.environ.get("SUBNET_NAME", "unknown")
    print(f"[NETWORK] ip={my_ip} subnet_id={subnet_id} subnet_name={subnet_name}")
    wait = int(os.environ.get("WAIT_SECONDS", 300))
    time.sleep(wait)
    return {"statusCode": 200, "body": f"Slept {wait}s — ENI held for duration"}
